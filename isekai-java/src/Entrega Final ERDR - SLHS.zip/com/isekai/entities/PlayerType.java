package com.isekai.entities;

public enum PlayerType {
    WIZARD,PALADIN,BERSERK,ARCHER,KNIGHT
}
