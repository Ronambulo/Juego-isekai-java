package com.isekai.entities.enemies.dragon;

public class DragonWorld2 extends Dragon{
    
    public DragonWorld2(){
        super();
        this.power = DEFAULT_POWER;
        this.lives = DEFAULT_LIVES;
    }
}
