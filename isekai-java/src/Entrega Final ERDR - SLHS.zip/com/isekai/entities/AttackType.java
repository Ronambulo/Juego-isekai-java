package com.isekai.entities;

public enum AttackType {
    RANGE,MELEE
}
